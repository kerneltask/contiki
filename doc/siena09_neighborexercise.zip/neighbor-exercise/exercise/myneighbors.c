/*
 * Copyright (c) 2009, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/**
 * \file
 *         Neighbor exercise: neighborhood library example
 * \author
 *         Fredrik Osterlind <fros@sics.se>
 */

#include "contiki.h"
#include "net/rime.h"

#include "myneighbors.h"

#include <stdio.h>

struct myneighbor {
  rimeaddr_t addr; /* 2b */
  int rssi; /* 2b */
};

#define MAX_NEIGHBORS 20
static struct myneighbor neighbors[MAX_NEIGHBORS]; /* Neighbor array */

/*---------------------------------------------------------------------------*/
void
myneighbors_init(void)
{
  int i;
  for (i=0; i < MAX_NEIGHBORS; i++) {
    rimeaddr_copy(&neighbors[i].addr, &rimeaddr_null);
  }
}
/*---------------------------------------------------------------------------*/
void
myneighbors_update(rimeaddr_t *neighbor, int rssi)
{
  int i;

  /* Locate neighbor */
  for (i=0; i < MAX_NEIGHBORS; i++) {
    if (rimeaddr_cmp(&neighbors[i].addr, neighbor)
        || rimeaddr_cmp(&neighbors[i].addr, &rimeaddr_null)) {
      break;
    }
  }
  if (i>=MAX_NEIGHBORS) {
    /* Neighbor list is full! */
    return;
  }

  if (rimeaddr_cmp(&neighbors[i].addr, neighbor)) {
    /* Update existing neighbor */
    neighbors[i].rssi = rssi;
    /*printf("neighbors[%i] = { %d.%d, %i }\n", i,
        neighbors[i].addr.u8[0], neighbors[i].addr.u8[1],
        neighbors[i].rssi);*/
    return;
  }

  /* Add new neighbor */
  rimeaddr_copy(&neighbors[i].addr, neighbor);
  neighbors[i].rssi = rssi;
  /*printf("neighbors[%i] = { %d.%d, %i } (ADDED)\n", i,
        neighbors[i].addr.u8[0], neighbors[i].addr.u8[1],
        neighbors[i].rssi);*/
}
/*---------------------------------------------------------------------------*/
static int
get_neighbor_rssi(int rank, rimeaddr_t *neighbor)
{
  int i, idx_1=-1, idx_2=-1, idx_3=-1;

  /* Extract top 3 neighbors */
  for (i=0; i < MAX_NEIGHBORS; i++) {
    if (rimeaddr_cmp(&neighbors[i].addr, &rimeaddr_null)) {
      /* End of list */
      break;
    }

    /* Sort */
    if (idx_1 < 0
        || neighbors[i].rssi > neighbors[idx_1].rssi) {
      idx_3 = idx_2;
      idx_2 = idx_1;
      idx_1 = i;
    } else if (idx_2 < 0
        || neighbors[i].rssi > neighbors[idx_2].rssi) {
      idx_3 = idx_2;
      idx_2 = i;
    } else if (idx_3 < 0
        || neighbors[i].rssi > neighbors[idx_3].rssi) {
      idx_3 = i;
    }
  }

  /* Rank: [1-3] */
  if (rank == 1) {
    i = idx_1;
  } else if (rank == 2) {
    i = idx_2;
  } else if (rank == 3) {
    i = idx_3;
  } else {
    /*printf("error: bad rank: %i\n", rank);*/
    rimeaddr_copy(neighbor, &rimeaddr_null);
    return 0;
  }
  if (i < 0) {
    rimeaddr_copy(neighbor, &rimeaddr_null);
    return 0;
  }
  rimeaddr_copy(neighbor, &neighbors[i].addr);
  return neighbors[i].rssi;
}
/*---------------------------------------------------------------------------*/
int
myneighbors_best(rimeaddr_t *neighbor)
{
  return get_neighbor_rssi(1, neighbor);
}
/*---------------------------------------------------------------------------*/
int
myneighbors_second_best(rimeaddr_t *neighbor)
{
  return get_neighbor_rssi(2, neighbor);
}
/*---------------------------------------------------------------------------*/
int
myneighbors_third_best(rimeaddr_t *neighbor)
{
  return get_neighbor_rssi(3, neighbor);
}
/*---------------------------------------------------------------------------*/
