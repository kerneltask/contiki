/*
 * Copyright (c) 2009, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/**
 * \file
 *         Neighbor exercise: top 3 neighbors by RSSI (SKELETON)
 * \author
 *         Fredrik Osterlind <fros@sics.se>
 */

#include "contiki.h"
#include "net/rime.h"

#include "dev/leds.h"
#include "dev/light.h"

#include "packets.h"
#include "myneighbors.h"

#include <stdio.h>

#include "node-id.h"

/*---------------------------------------------------------------------------*/
PROCESS(report_neighbors_process, "Report neighbors");
PROCESS(send_light_process, "Broadcast light");
AUTOSTART_PROCESSES(&report_neighbors_process, &send_light_process);
/*---------------------------------------------------------------------------*/
static void
recv_light(struct broadcast_conn *c, rimeaddr_t *from)
{
  struct light_msg msg;

  if (packetbuf_datalen() != sizeof(struct light_msg)) {
    /* Bad size */
    return;
  }

  packetbuf_copyto(&msg); /* Copy packet data */
  if (msg.type != TYPE_LIGHT) {
    /* Bad type */
    return;
  }

  /* We received a broadcast message from a neighbor.
   * Update our neighbor list using neighbors RSSI */
  printf("TODO #9 Update our neighbor list\n"); /* ex-neighbors.c */
  leds_toggle(LEDS_GREEN);
}
/*---------------------------------------------------------------------------*/
static void
recv_report(struct unicast_conn *c, rimeaddr_t *from)
{
  /* We should never receive any reports, only the projector should do that! */
}
/*---------------------------------------------------------------------------*/
static const struct broadcast_callbacks broadcast_call = {recv_light};
static struct broadcast_conn light_broadcast;
static const struct unicast_callbacks unicast_call = {recv_report};
static struct unicast_conn report_unicast;
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(send_light_process, ev, data)
{
  static struct etimer et;
  PROCESS_EXITHANDLER(broadcast_close(&light_broadcast);)

  PROCESS_BEGIN();

  /* Open broadcast channel on LIGHT_CHANNEL */
  printf("TODO #1 Open broadcast channel on LIGHT_CHANNEL\n"); /* ex-broadcast-rssi.c */

  /* Send light every 5 seconds */
  etimer_set(&et, 5*CLOCK_SECOND);

  while(1) {
    struct light_msg msg;

    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
    etimer_reset(&et);

    msg.type = TYPE_LIGHT;

    /* Our position */
    msg.pos_x = 0;
    msg.pos_y = 0;
    printf("TODO #3 Estimate our (X,Y) coordinates [1-100]: (%d,%d)\n",
        msg.pos_x, msg.pos_y);

    /* Sample light */
    msg.light = 0;
    printf("TODO #4 Sample light sensor: %d\n", msg.light); /* ex-light.c */

    /* Broadcast light and position message */
    packetbuf_copyfrom((char*)&msg, sizeof(struct light_msg));
    printf("TODO #2 Send broadcast message\n"); /* ex-broadcast-rssi.c */
    leds_toggle(LEDS_RED);
  }

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(report_neighbors_process, ev, data)
{
  static struct etimer et;
  PROCESS_EXITHANDLER(unicast_close(&report_unicast);)

  PROCESS_BEGIN();

  /* Initialize neighbor library */
  printf("TODO #8 Initialize neighbor library\n"); /* ex-neighbors.c */

  /* Open unicast channel on REPORT_CHANNEL */
  printf("TODO #5 Open unicast channel on REPORT_CHANNEL\n"); /* /examples/rime/example-unicast.c */

  /* Delay 2.5 seconds */
  etimer_set(&et, 5*CLOCK_SECOND/2);
  PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));

  /* Send neighbor report every 5 seconds */
  etimer_set(&et, 5*CLOCK_SECOND);

  while(1) {
    struct report_msg msg;
    rimeaddr_t projector;

    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));
    etimer_reset(&et);

    /* Create report */
    msg.type = TYPE_REPORT;

    /* Extract top neighbors sorted by RSSI */
    rimeaddr_copy(&msg.neighbor1, &rimeaddr_null); msg.neighbor1_rssi = 0;
    rimeaddr_copy(&msg.neighbor2, &rimeaddr_null); msg.neighbor2_rssi = 0;
    rimeaddr_copy(&msg.neighbor3, &rimeaddr_null); msg.neighbor3_rssi = 0;
    printf("TODO #10 Extract top 3 neighbors: %d.%d(%i) %d.%d(%i) %d.%d(%i)\n",
        msg.neighbor1.u8[0], msg.neighbor1.u8[1], msg.neighbor1_rssi,
        msg.neighbor2.u8[0], msg.neighbor2.u8[1], msg.neighbor2_rssi,
        msg.neighbor3.u8[0], msg.neighbor3.u8[1], msg.neighbor3_rssi); /* ex-neighbors.c */

    /* Enter projector address */
    projector.u8[0] = 0; /* Projector address (first byte) */
    projector.u8[1] = 0; /* Projector address (second byte) */
    printf("TODO #6 Enter projector Rime address: %d.%d\n", projector.u8[0], projector.u8[1]);

    /* Send unicast message with neighbor information to projector */
    packetbuf_copyfrom((char*)&msg, sizeof(struct report_msg));
    printf("TODO #7 Send unicast message to projector\n"); /* /examples/rime/example-unicast.c */
    leds_toggle(LEDS_BLUE);
  }

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
