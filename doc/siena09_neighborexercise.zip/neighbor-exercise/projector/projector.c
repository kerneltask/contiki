/*
 * Copyright (c) 2009, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/**
 * \file
 *         Neighbor exercise: sink program
 * \author
 *         Fredrik Osterlind <fros@sics.se>
 */


#include "contiki.h"
#include "net/rime.h"

#include "packets.h"
#include "myneighbors.h"

#include <stdio.h>

/*---------------------------------------------------------------------------*/
PROCESS(sink_process, "Report neighbors");
AUTOSTART_PROCESSES(&sink_process);
/*---------------------------------------------------------------------------*/
static void
recv_light(struct broadcast_conn *c, rimeaddr_t *from)
{
  struct light_msg msg;

  if (packetbuf_datalen() != sizeof(struct light_msg)) {
    /* Bad size */
    return;
  }

  packetbuf_copyto(&msg); /* Copy packet data */
  if (msg.type != TYPE_LIGHT) {
    /* Bad type */
    return;
  }

  printf("%d.%d LIGHT %u.%u %u\n",
      from->u8[0], from->u8[1],
      msg.pos_x, msg.pos_y,
      msg.light);
}
/*---------------------------------------------------------------------------*/
static void
recv_report(struct unicast_conn *c, rimeaddr_t *from)
{
  if (packetbuf_datalen() == sizeof(struct report_msg)) {
    struct report_msg msg;
    packetbuf_copyto(&msg); /* Copy packet data */
    if (msg.type != TYPE_REPORT) {
      /* Bad type */
      return;
    }

    printf("%d.%d REPORT %d.%d %d %d.%d %d %d.%d %d\n",
        from->u8[0], from->u8[1],
        msg.neighbor1.u8[0], msg.neighbor1.u8[1],
        (signed char) (0xFF&msg.neighbor1_rssi),
        msg.neighbor2.u8[0], msg.neighbor2.u8[1],
        (signed char) (0xFF&msg.neighbor2_rssi),
        msg.neighbor3.u8[0], msg.neighbor3.u8[1],
        (signed char) (0xFF&msg.neighbor3_rssi)
    );
    return;
  }

  if (packetbuf_datalen() == sizeof(struct alarm_msg)) {
    /* TODO Alarm messages? */
    struct alarm_msg msg;
    packetbuf_copyto(&msg); /* Copy packet data */
    if (msg.type != TYPE_ALARM) {
      /* Bad type */
      return;
    }

    printf("%d.%d ALARM %d.%d\n",
        from->u8[0], from->u8[1],
        msg.bad_neighbor.u8[0], msg.bad_neighbor.u8[1]);
    return;
  }
}
/*---------------------------------------------------------------------------*/
static const struct broadcast_callbacks broadcast_call = {recv_light};
static struct broadcast_conn light_broadcast;
static const struct unicast_callbacks unicast_call = {recv_report};
static struct unicast_conn report_unicast;
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(sink_process, ev, data)
{
  PROCESS_EXITHANDLER(
      broadcast_close(&light_broadcast);
      unicast_close(&report_unicast);)

  PROCESS_BEGIN();

  broadcast_open(&light_broadcast, LIGHT_CHANNEL, &broadcast_call);
  unicast_open(&report_unicast, REPORT_CHANNEL, &unicast_call);

  printf("I AM THE SINK\n");

  PROCESS_WAIT_EVENT_UNTIL(0);

  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
